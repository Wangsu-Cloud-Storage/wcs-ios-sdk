//
//  WCSiOS.h
//  WCSiOS
//
//  Created by mato on 2017/3/6.
//  Copyright © 2017年 CNC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WCSClient.h"

//! Project version number for WCSiOS.
FOUNDATION_EXPORT double WCSiOSVersionNumber;

//! Project version string for WCSiOS.
FOUNDATION_EXPORT const unsigned char WCSiOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WCSiOS/PublicHeader.h>


